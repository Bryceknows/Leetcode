package DynamicProgramming.Sequence;

/**
 * @author Bryce
 * @project Leetcode
 * @date 2021/7/16
 * 题目：不相交的线
 * 题解：
 * 方法：二维DP（思路一）
 * 笔记：本题与M_1143的代码一模一样
 本题 dp[i][j] 表示dp[i][j] 表示 num1 的前 i-1 个，num2 的前 j-1 个的最大不相交的线个数。
 画图推导：nums1 = [2,5,1,2,5]  nums2 = [10,5,2,1,5,2]
    i	2	5	1	2	5
 j	0	0	0	0	0	0
 10	0	0   0   0   0   0
 5	0	0   1   1   1   1
 2	0	1   1   1   2   2
 1  0   1   1   2   2   2
 5  0   1   2   2   2   3
 2  0   1   2   2   3   3
若 nums1[i-1] == nums2[j-1]，则 dp[i][j] = dp[i-1][j-1] + 1 (这轮比较的两个数被用于+1了，不能重复计算，所以继承的是左上角的值并加1)
否则 dp[i][j] = max(dp[i-1][j], dp[i][j-1]) （继承上边或者左边的值）
 **/
public class M_1035 {
    public int maxUncrossedLines(int[] nums1, int[] nums2) {
        int[][] dp = new int[nums1.length + 1][nums2.length + 1];
        int res = 0;

        for (int i = 1; i < nums1.length + 1; i++) {
            for (int j = 1; j < nums2.length + 1; j++) {
                if (nums1[i - 1] == nums2[j - 1]) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }

        }
        return dp[nums1.length][nums2.length];
    }
}