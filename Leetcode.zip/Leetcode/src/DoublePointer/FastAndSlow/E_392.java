package DoublePointer.FastAndSlow;

/**
 * @author Bryce
 * @project Leetcode
 * @date 2021/7/19
 * 题目：判断子序列
 * 题解：
 * 方法：双指针法（快慢指针）
 * 笔记：
 **/
public class E_392 {
    public boolean isSubsequence(String s, String t) {
        //特殊情况处理
        if(s.length()==0)return true;
        if(s.length()>t.length())return false;

        char[] ss = s.toCharArray();
        char[] tt = t.toCharArray();
        int l = 0;
        for (char r : tt) {
            if (r == ss[l]) {
                l++;
                if (l == ss.length) return true;
            }
        }
        return false;
    }
}
