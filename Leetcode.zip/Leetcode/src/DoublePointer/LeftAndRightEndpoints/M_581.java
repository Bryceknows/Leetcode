package DoublePointer.LeftAndRightEndpoints;

import java.util.Arrays;

/**
 * @author Bryce
 * @project Leetcode
 * @date 8/3/2021
 * 题目：最短无序连续子数组
 * 题解：
 * 方法：双指针法（左右端点指针）
 * 笔记：
 **/
public class M_581 {
    public int findUnsortedSubarray(int[] nums) {
        if (nums.length == 0 || nums.length == 1) return 0;
        int[] arr = nums.clone();
        Arrays.sort(nums);
        int l = 0, r = nums.length - 1;
        for (l = 0; l < nums.length; l++) {
            if (arr[l] != nums[l]) break;
        }
        for (r = nums.length - 1; r >= l; r--) {
            if (arr[r] != nums[r]) break;
        }
        return r - l + 1;
    }
}
