package DoublePointer.SlidingWindow;

/**
 * @author Bryce
 * @project Leetcode
 * @date 2021/7/14
 * 题目：最长连续递增序列
 * 题解：
 * 方法：滑动窗口（可变窗口大小）
 * 笔记：
 **/
public class E_674 {
    public int findLengthOfLCIS(int[] nums) {
        int n = nums.length;
        if (n <= 1) return n;
        int maxLength = 0;
        int l = 0;
        for (int r = 1; r < n; r++) {
            if (nums[r] <= nums[r - 1]) {
                maxLength = Math.max(maxLength, r - l);
                l = r;
            } else if (r == n - 1) {  // nums有可能以递增序列结尾，如 [9,8,7,1,2,3,4]
                maxLength = Math.max(maxLength, r - l + 1);
            }
        }
        return maxLength;
    }
}
