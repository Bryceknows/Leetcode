package DoublePointer.SlidingWindow;

/**
 * @author Bryce
 * @project Leetcode
 * @date 8/3/2021
 * 题目：无重复字符的最长子串
 * 题解：
 * 方法：滑动窗口（可变窗口大小）+ 哈希表（数组实现）
 * 笔记：
 **/
public class M_3 {
    public int lengthOfLongestSubstring(String s) {
        if(s.length()==0)return 0;

        char[] ss = s.toCharArray();
        int[] hash = new int[128];  //128个ASCII码
        int res=0;
        int l=0;
        for(int r=0;r<ss.length;r++){
            hash[ss[r]]++;  // hash[ss[r]]表示ss[r]在窗口中出现的频次
            while(hash[ss[r]]>1){
                hash[ss[l]]--;
                l++;
            }
            res=Math.max(res,r-l+1);
        }
        return res;
    }
}
